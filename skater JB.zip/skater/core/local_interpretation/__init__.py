from .text_interpreter import *

__all__ = [relevance_wt_assigner]
