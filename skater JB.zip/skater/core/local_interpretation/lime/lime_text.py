"""
Making LimeTextExplainer Accessible
"""

from lime.lime_text import LimeTextExplainer
