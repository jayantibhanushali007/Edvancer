"""Core Interpretation Objects. All attached interpreters have access to the same
model tools and data set tools."""
