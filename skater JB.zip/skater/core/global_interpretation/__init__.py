"""Submodule for all interpretations that cover *regions* of the domain,
rather than individual points."""
